#==============================================================================
# Specific hues
#==============================================================================
module PokemonColorVariants

  SPECIFIC_HUE_ENABLED = false # Use only specific hues

  # Hue map (SPECIFIC_HUE_ENABLED should be true)
  POKEMON_HUE = {
    # Example: :SPECIES => [value1, value2, value3, ...],
    :PIKACHU => [100, 250]
  }
end
